angular.module('app.controllers', ['jett.ionic.filter.bar'])
  
.controller('homeCtrl', function($scope, $ionicFilterBar, $http) {
     $scope.shouldShowDelete = true;
     $scope.shouldShowReorder = true;
     $scope.listCanSwipe = true;
     
//    $scope.items = [{title:"taste", description:"the"},{title:"the",description:"smoke"}, {title:"apple",description:"123"}];
//    
//    $scope.showFilterBar = function () {
//      filterBarInstance = $ionicFilterBar.show({
//        items: $scope.items,
//        update: function (filteredItems, filterText) {
//          $scope.items = filteredItems;
//          if (filterText) {
//            console.log(filterText);
//          }
//        },
//          filterProperties: 'title'
//      });
//    };
//    return $scope;
    
    var link = 'http://ec2-52-91-251-221.compute-1.amazonaws.com:8080/CliniConnectAdmin3/GetPatientsTable';
    

        var vm = this,
        items = [],
        filterBarInstance;
    
        $http.get(link).then(function (response){
            for(var i = 0; i < response.data.patients.length; i++){
                
                var item = {
                    patient: response.data.patients[i].name,
                    date: response.data.patients[i].date,
                    dr: response.data.patients[i].dr
                };
                items.push(item);
            }
        });

    vm.items = items;

    vm.showFilterBar = function () {
      filterBarInstance = $ionicFilterBar.show({
        items: vm.items,
        update: function (filteredItems) {
          vm.items = filteredItems;
        },
        filterProperties: 'patient'
      });
    };

    return vm;
    

})
   
.controller('appointmentReminderCtrl', function($scope) {

})
   
.controller('sendLabsCtrl', function($scope) {

})
      
.controller('registerPatientCtrl', function($scope) {

})
   
.controller('clinicInformationCtrl', function($scope) {

})
 